//Compute the transitive closure of a given directed graph using Warshall's algorithm
#include <iostream>
#include <vector>

using namespace std;

void warshall(int n, vector<vector<int>>& adj_matrix) {
    for (int k = 0; k < n; ++k) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                adj_matrix[i][j] = adj_matrix[i][j] || (adj_matrix[i][k] && adj_matrix[k][j]);
            }
        }
    }
}

int main() {
    int n;
    cout << "Enter the number of vertices: ";
    cin >> n;

    vector<vector<int>> adj_matrix(n, vector<int>(n, 0));

    cout << "Enter the adjacency matrix:\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> adj_matrix[i][j];
        }
    }

    warshall(n, adj_matrix);

    cout << "Transitive closure of the graph:\n";
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout << adj_matrix[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
