#include<iostream>
#include<algorithm>

using namespace std;

struct item {
    int value;
    int weight;
    float ratio;
};

bool compare(item x, item y) {
    return x.ratio > y.ratio;
}

int main() {
    
    int num_item, tWeight, i;
    cout<<"Enter total number of Items: ";
    cin>>num_item;
    
    item items[num_item];
    
    cout<<"Enter total Weight: ";
    cin>>tWeight;
    
    for(i=0; i<num_item; i++) {
        cout<<"Enter item_"<<i+1<< " Value and Weight: \n";
        cin>> items[i].value>> items[i].weight;
        items[i].ratio = (float)items[i].value / items[i].weight;
    }
    
    for(i=0; i<num_item; i++) {
        cout<<"Item_"<<i+1<<" Ratio: "<<items[i].ratio<<"\n";
    }
    
    sort(items, items + num_item, compare);
    
    float total_value = 0;
    for(i = 0; i < num_item; i++) {
        if(tWeight == 0) {
            break;
        }
        if(items[i].weight <= tWeight) {
            total_value += items[i].value;
            tWeight -= items[i].weight;
        }
        else {
            total_value += (float)tWeight / items[i].weight * items[i].value;
            tWeight = 0;
        }
    }
    cout << "The maximum value that can be put into the knapsack is: " << total_value;
    
    return 0;
}