#include<iostream>
#include<cmath>
using namespace std;

int board[20], count;

bool isSafe(int row, int col) {
   for(int i = 0; i < row; i++) {
      if(board[i] == col || abs(board[i] - col) == abs(i - row))
         return false;
   }
   return true;
}

void printBoard(int n) {
   for(int i = 0; i < n; i++) {
      for(int j = 0; j < n; j++) {
         if(board[i] == j)
            cout<<"Q ";
         else
            cout<<"- ";
      }
      cout<<endl;
   }
}

void nQueens(int row, int n) {
   for(int col = 0; col < n; col++) {
      if(isSafe(row, col)) {
         board[row] = col;
         if(row == n-1) {
            count++;
            cout<<"Solution "<<count<<":\n";
            printBoard(n);
         } else {
            nQueens(row+1, n);
         }
      }
   }
}

int main() {
   int n;
   cout<<"Enter the number of queens: ";
   cin>>n;
   nQueens(0, n);
   return 0;
}
