//Quick sort
#include<iostream>
using namespace std;
int partition(int arr[], int s, int e) {
    int pivot = arr[s]; //find pivot
    int cnt = 0;  //count no. of element smaller then pivot.
    for(int i = s+1; i<=e; i++) {
        if(arr[i] <=pivot) {
            cnt++;
        }
    }
    int pivotIndex = s + cnt;    //place pivot at right position
    swap(arr[pivotIndex], arr[s]);
    int i = s, j = e;      //left and right part 
    while(i < pivotIndex && j > pivotIndex) {
        while(arr[i] <= pivot) 
        {
            i++;
        }
        while(arr[j] > pivot) {
            j--;
        }
        if(i < pivotIndex && j > pivotIndex) {
            swap(arr[i++], arr[j--]);
        }
    }
    return pivotIndex;
}
void quickSort(int arr[], int s, int e) {   //creating quick sort function. //s=starting index, e=ending index.
    if(s >= e)    //base case
        return;
    int p = partition(arr, s, e);   //partition 
    quickSort(arr, s, p-1);  //left part sort
    quickSort(arr, p+1, e);  //right part sort
}
int main() {
    int arr[50], n;
    cout<<"Enter the size: ";
    cin>>n;
    cout<<"Enter array elements"<<endl;
    for(int i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    quickSort(arr, 0, n-1);  //calling sort function.
    cout << "Sorted array using quick sort is: ";   //print sorted array
    for(int i=0; i<n; i++) 
    {   
        cout << arr[i] << " ";
    }
    return 0;
}