//WAP to print address of the array 
#include <iostream>
int main()
{
    int arr[]{1,2,3,4,5};
    std::cout<<arr<<'\t'<<&arr;
    return 0;
}